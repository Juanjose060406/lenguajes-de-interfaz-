PRACTICAS MASM x86 - UNIDAD 2
Materia: Lenguajes de Interfaz - Unidad 2
Nombre: Angulo Martinez Juan Jose
Horario: 8:00-9:00 a. m.
Docente: Dr. Jose Luis Medina Jimenez

REQUISITOS
- Visual Studio con MASM x86 de 32 bits.
- Irvine32 instalado y configurado.
- Cada archivo .asm es un programa independiente: compila y ejecuta uno a la vez.
- Los codigos son ejemplos base para las practicas; adapta los ejercicios a las instrucciones exactas que haya dado el docente.

INDICE
01_Ciclos_Numericos.asm
02_Captura_Despliegue_Mensaje.asm
03_Comparacion_Prueba.asm
04_Saltos.asm
04_1_Mayor_Menor_Igual.asm
05_Condicionales.asm
05_1_Repetir_Hasta_Cero.asm
06_Decremento_Incremento.asm
06_1_Ocupacion_Estacionamiento.asm
07_Validacion_Formato.asm
08_Operaciones_Aritmeticas.asm
09_PUSH_POP.asm
10_Cadena_Decimal.asm
11_Operaciones_Logicas.asm
12_Desplazamiento_Rotacion.asm
13_String_Hexadecimal.asm
14_Captura_Almacenamiento_Dato.asm
15_Manipulacion_Archivo.asm

NOTA
Los ejemplos que requieren entrada numerica usan ReadDec/ReadInt como ayuda de Irvine32, salvo las practicas 7 y 14 que validan texto con ReadString. Si la consigna de una practica prohíbe una instrucción específica, revisa esa restricción antes de entregar.
